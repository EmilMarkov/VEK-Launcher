// src/store/actions/torrentActions.ts
import { FETCH_TORRENTS, FetchTorrentsRequest, FetchTorrentsSuccess, FetchTorrentsFailure, ITorrent } from '@/types/torrents';

export const fetchTorrentsRequest = (): FetchTorrentsRequest => ({
  type: FETCH_TORRENTS,
  status: 'REQUEST'
});

export const fetchTorrentsSuccess = (torrents: ITorrent[]): FetchTorrentsSuccess => ({
  type: FETCH_TORRENTS,
  status: 'SUCCESS',
  torrents
});

export const fetchTorrentsFailure = (message: string): FetchTorrentsFailure => ({
  type: FETCH_TORRENTS,
  status: 'FAILURE',
  message
});
